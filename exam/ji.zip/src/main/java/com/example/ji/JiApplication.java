package com.example.ji;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JiApplication {

    public static void main(String[] args) {
        SpringApplication.run(JiApplication.class, args);
    }

}
