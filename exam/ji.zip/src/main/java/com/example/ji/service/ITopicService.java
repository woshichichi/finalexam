package com.example.ji.service;

import com.example.ji.entity.Topic;

import java.util.List;

public interface ITopicService {
    List<Topic> findAllTopic();

}
